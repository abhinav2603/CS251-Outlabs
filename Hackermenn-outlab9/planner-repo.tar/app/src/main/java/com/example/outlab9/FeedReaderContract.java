package com.example.outlab9;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.os.strictmode.SqliteObjectLeakedViolation;
import android.provider.BaseColumns;

import android.util.Log;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Vector;

//import static java.security.AccessController.getContext;


public final class FeedReaderContract {
    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.

    private static int noTasks=0;
    private static Vector<Integer> noSubTasks;
    public static final String TAG="Database";
    static String rootName="Zen";
    private FeedReaderContract()
    {
        Log.i(TAG,"Making Database");
    }

    //make the database
    public static void createDB()
    {
        //FeedReaderDbHelper dbHelper = new FeedReaderDbHelper(getContext());
    }

    public static void insertTask(ContentValues values, FeedReaderDbHelper dbHelper, MyAdapter mAdapter)
    {
        Log.i(TAG,"Entered insertTask");

        noTasks++;
        noSubTasks.add(0);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        values.put(FeedReaderContract.Tasks.COL1, FeedReaderContract.noTasks-1);
        db.insertWithOnConflict(FeedReaderContract.Tasks.TABLE_NAME, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
        Log.d(TAG,"number of tasks now (same as inserted node id)are: "+noTasks);
        mAdapter.addNode(values,noTasks);
    }

    public static void insertSubTask(ContentValues values, FeedReaderDbHelper dbHelper, MyAdapter mAdapter, int taskId)
    {
        Log.i(TAG,"Entered insertSubTask");

        int oldSubTaskNo=noSubTasks.get(taskId);
        noSubTasks.set(taskId,oldSubTaskNo+1);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        values.put(SubTasks.COL1,taskId);
        values.put(SubTasks.COL2,oldSubTaskNo);
        db.insertWithOnConflict(FeedReaderContract.SubTasks.TABLE_NAME, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        db.close();

        mAdapter.addNode(values,noSubTasks.get(taskId));

    }

    public static void updateTask(FeedReaderDbHelper dbHelper,ContentValues values, int taskId, MyAdapter myAdapter)
    {
        String date="";
        boolean dateView=false;
        if(values.size()>3)
        {//DayView
            date=(String)values.get("Date");
            values.remove("Date");
            dateView=true;
        }
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        String whereClause=Tasks.COL1+" =?";
        String[] whereArgs={((Integer) taskId).toString()};
        db.update(Tasks.TABLE_NAME,values,whereClause,whereArgs);
        if(dateView)
            myAdapter.initDataSet(db,date);
        else
        {
            myAdapter.initDataSet(db);
            myAdapter.notifyItemChanged(taskId);
        }
    }

    public static void updateSubTask(FeedReaderDbHelper dbHelper,ContentValues values, int subTaskId, int taskId, MyAdapter myAdapter)
    {
        Log.d(TAG,"Updating subtask for subtask id: "+subTaskId);
        String date="";
        boolean dateView=false;
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        String whereClause=SubTasks.COL1+" =?"+" AND "+SubTasks.COL2+" =?";
        String[] whereArgs={((Integer) taskId).toString(),((Integer) subTaskId).toString()};
        if(values.size()>3)
        {//DayView
            Log.d(TAG,"updating subtask in DayView");
            date=(String)values.get("Date");
            values.remove("Date");
            dateView=true;
        }
        db.update(SubTasks.TABLE_NAME,values,whereClause,whereArgs);
        if(dateView)
            myAdapter.initDataSet(db,date);
        else
        {
            myAdapter.initDataSet(db);
            myAdapter.notifyItemChanged(subTaskId);
        }

    }
    public static void updateSubTask(FeedReaderDbHelper dbHelper,ContentValues values, int subTaskId, int taskId)
    {
        Log.d(TAG,"Updating subtask for subtask id: "+subTaskId);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        String whereClause=SubTasks.COL1+" =?"+" AND "+SubTasks.COL2+" =?";
        String[] whereArgs={((Integer) taskId).toString(),((Integer) subTaskId).toString()};
        Log.d(TAG,taskId+" "+subTaskId);
        db.update(SubTasks.TABLE_NAME,values,whereClause,whereArgs);
    }

    //public static String getTaskName(String id){
        //SQLiteDatabase db = dbHelper.getReadableDatabase();
    //}

    public static void initialiseDbVar(FeedReaderDbHelper dbHelper)
    {
        Log.i(TAG,"Initialising database variables");
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        noTasks= (int) DatabaseUtils.queryNumEntries(db, Tasks.TABLE_NAME);
        //Log.d(TAG,"no of tasks found="+noTasks);
        Cursor curs=db.rawQuery("SELECT "+SubTasks.COL1+", COUNT("+SubTasks.COL2+") FROM "+SubTasks.TABLE_NAME+" GROUP BY "+SubTasks.COL1
        +";",null);
        noSubTasks = new Vector<Integer>();
        for(int i=0;i<noTasks;i++)
            noSubTasks.add(0);
        //Log.d(TAG,"Size of noSubTasks is "+noSubTasks.size());
        if(curs.getCount()>0)
        {
            while(curs.moveToNext()) {
                int taskID = curs.getInt(curs.getColumnIndexOrThrow(SubTasks.COL1));
                Log.d(TAG,"taskID: "+taskID);
                noSubTasks.set(taskID,curs.getInt(1));
            }
        }
        curs.close();
        /*String debugMsg="";
        for(int i:noSubTasks)
            debugMsg=debugMsg+" "+i;
        Log.d(TAG,"noSubTask array is "+debugMsg);*/

    }

    /* Inner class that defines the table contents */
    public static class Tasks implements BaseColumns {
        public static final String TABLE_NAME = rootName;
        public static final String COL1 = "Task_id";
        public static final String COL2 = "name";
        public static final String COL3="description";
        public static final String COL4="scheduled";
        //public static final String COL5="subtasks";
        //public static final String COLUMN_NAME_SUBTITLE = "subtitle";

    }
    public static class SubTasks implements BaseColumns
    {
        public static final String TABLE_NAME="SubTasks";
        public static final String COL1="Task_id";
        public static final String COL2="Subtask_id";
        public static final String COL3="name";
        public static final String COL4="description";
        public static final String COL5="scheduled";
    }


    private static final String CREATE_TAB1="CREATE TABLE "+ Tasks.TABLE_NAME+"( "+Tasks.COL1+" INTEGER PRIMARY KEY," +
            Tasks.COL2+" TEXT, "+Tasks.COL3+" TEXT, "+ Tasks.COL4+" TIMESTAMP);";
    private static final String CREATE_TAB2="CREATE TABLE "+ SubTasks.TABLE_NAME+"( "+SubTasks.COL1+" INTEGER, "+
            SubTasks.COL2+" INTEGER, "+SubTasks.COL3+" TEXT, "+SubTasks.COL4+" TEXT, "+SubTasks.COL5+" TIMESTAMP," +
            "PRIMARY KEY("+SubTasks.COL1+", "+SubTasks.COL2+"));";
    private static final String DELETE_TAB1="DROP TABLE IF EXISTS "+Tasks.TABLE_NAME;
    private static final String DELETE_TAB2="DROP TABLE IF EXISTS "+SubTasks.TABLE_NAME;



    public static class FeedReaderDbHelper extends SQLiteOpenHelper
    {
        // If you change the database schema, you must increment the database version.
        public static final int DATABASE_VERSION = 1;
        public static final String DATABASE_NAME = "ToDo.db";
        public static final String TAG="Database helper";
        public FeedReaderDbHelper(Context context)
        {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }
        public void onCreate(SQLiteDatabase db) {
            Log.i(TAG,"Creating the tables");
            db.execSQL(CREATE_TAB1);
            db.execSQL(CREATE_TAB2);
            //seed the entries

            db.execSQL("INSERT INTO "+Tasks.TABLE_NAME+" VALUES(0, \"Acads\", \"Padhai ki baatein\", " +
                    "\"2019-12-31\");");
            db.execSQL("INSERT INTO "+Tasks.TABLE_NAME+" VALUES(1, \"Self Improvement\", \"Reading list, blogs, exercise, etc.\", " +
                    "\"2019-12-30\");");
            db.execSQL("INSERT INTO "+Tasks.TABLE_NAME+" VALUES(2, \"Research\", \"Pet projects\", " +
                    "null);");
            db.execSQL("INSERT INTO "+Tasks.TABLE_NAME+" VALUES(3,\"Hobbies\", \"<3\", null);");
            noTasks+=4;

            //enter the subtasks
            //noSubTasks.add(0);

            db.execSQL("INSERT INTO "+SubTasks.TABLE_NAME+" VALUES(1,0,\"Exercise\", \"someday?\", \"2021-2-29\");");
            db.execSQL("INSERT INTO "+SubTasks.TABLE_NAME+" VALUES(1,1,\"Reading list\", " +
                    " \"My bucket list:\nHear the Wind Sing\nThe Fountainhead\nAtlas Shrugged\nA prisoner of birth\"," +
                    " null);");
            //noSubTasks.add(2);

            //noSubTasks.add(0);

            db.execSQL("INSERT INTO "+SubTasks.TABLE_NAME+" VALUES(3,0,\"Origami\"," +
                    "\"cranes and tigers.\", \"2019-10-29\");");
            db.execSQL("INSERT INTO "+SubTasks.TABLE_NAME+" VALUES(3,1,\"Drum practice!\", " +
                    "\"Aim:\\nHallowed be thy name,\\nAcid Rain (LTE)\", \"2019-10-29\");");
            //noSubTasks.add(2);
            //FeedReaderDbHelper dbHelper = new FeedReaderDbHelper(getContext());


        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            Log.w(TAG,"Deleting all tables");
            db.execSQL(DELETE_TAB1);
            db.execSQL(DELETE_TAB2);
            onCreate(db);
        }
        /*public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }*/
    }
}