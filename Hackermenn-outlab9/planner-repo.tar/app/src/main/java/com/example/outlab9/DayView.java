package com.example.outlab9;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DayView extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    Toolbar toolbar;
    DrawerLayout fullView;
    DrawerLayout drawer;
    NavigationView navigationView;
    ActionBarDrawerToggle toggle;
    Activity activity = this;

    private FeedReaderContract.FeedReaderDbHelper dbHelper;
    public static final String TAG = "Day_view";
    private RecyclerView recyclerView;
    private MyAdapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-d");
        date = df.format(c);
        if(date.charAt(date.length()-2)=='0')
        {
            String temp=date.substring(0,date.length()-2);
            temp+=date.charAt(date.length()-1);
            date=temp;
        }
        Log.d(TAG,date+"1");
        setContentView(R.layout.activity_day_view);
        Log.d(TAG,date+"2");
        //setContentView(R.layout.activity_main);
        Log.d(TAG,date);
        //Log.d(TAG,"here2");
        dbHelper= new FeedReaderContract.FeedReaderDbHelper(this);
        //Log.d(TAG,"here3");
        createUI();
        Log.d(TAG,date+"3");
        FeedReaderContract.initialiseDbVar(dbHelper);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.day_view_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onResume()
    {
        Log.i(TAG,"Entering onResume()");
        super.onResume();
        mAdapter.initDataSet(dbHelper.getReadableDatabase(),date);
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void setContentView(int layoutResID) {
        fullView = (DrawerLayout) getLayoutInflater().inflate(R.layout.activity_game_template, null);
        FrameLayout activityContainer = (FrameLayout) fullView.findViewById(R.id.game_template_activity_content);
        getLayoutInflater().inflate(layoutResID, activityContainer, true);
        super.setContentView(fullView);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        ((TextView) findViewById(R.id.main_toolbar).findViewById(R.id.topName)).setText(FeedReaderContract.rootName);

        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                hideKeyboard(activity);
                super.onDrawerOpened(drawerView);
            }
        };
        if (useDrawer()) {
            drawer.addDrawerListener(toggle);
            toggle.syncState();
            navigationView.setNavigationItemSelectedListener(this);
        } else {
            drawer.setVisibility(View.GONE);
        }
    }

    protected boolean useDrawer() {
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_day_view) {
            //Intent intent = new Intent(getApplicationContext(), DayView.class);
            //startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add_date:
                Log.d(TAG, "Add a new date");
                int mYear, mMonth, mDay, mHour, mMinute;
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                date = year+"-" + (monthOfYear + 1) +"-"+dayOfMonth ;
                                mAdapter.initDataSet(dbHelper.getReadableDatabase(),date);
                                mAdapter.notifyDataSetChanged();
                            }
                        },mYear,mMonth,mDay);
                dialog.show();
                Log.d(TAG,date);
                //createUI();

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void createUI(){
        //code for recyclerView
        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);

        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        Log.d(TAG,date+"5");

        // specify an adapter (see also next example)
        mAdapter = new MyAdapter(dbHelper,this,2,date);
        Log.d(TAG,date+"6");
        recyclerView.setAdapter(mAdapter);
        Log.d(TAG,date+"7");

        //toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        ((TextView)findViewById(R.id.main_toolbar).findViewById(R.id.topName)).setText("Day View");
    }
}
