package com.example.outlab9;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.Adapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MyAdapter extends Adapter<MyAdapter.MyViewHolder>
{
    private int activityType=0;//1 for taskDetail
    private int typeNo;//use when not in MainActivity
    private List<String> titles;
    private String typedate;
    public static final String TAG="My_Ada_pter";
    private static final long DOUBLE_PRESS_INTERVAL = 250; // in millis
    private long lastPressTime;
    private List<String> tasks,scheduled,descriptions;
    private List<String> extraVals;
    private List<List<String> > subTasks;
    Context cont_text;
    private boolean anotherOpen=false;
    private MyViewHolder currentOpen;
    MyAdapter(FeedReaderContract.FeedReaderDbHelper dbHelper, Context context)
    {
        cont_text = context;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        initDataSet(db);
        activityType = 0;
        /*Cursor cursor=db.query(FeedReaderContract.Tasks.TABLE_NAME,null,null,null,null,null,null);
        titles = new ArrayList<>();
        tasks= new ArrayList<>();
        scheduled = new ArrayList<>();
        descriptions=new ArrayList<>();
        subTasks=new ArrayList<>();
        while(cursor.moveToNext()) {
            String title = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL1));
            String taskName = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL2));
            String sched = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL4));
            String desc=cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL3));
            String[] selectionList={FeedReaderContract.SubTasks.COL3},
                    argList={cursor.getString(cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL1))};
            String condn=FeedReaderContract.SubTasks.COL1+" =?";
            Cursor cursor1=db.query(
                    FeedReaderContract.SubTasks.TABLE_NAME,selectionList,condn,argList,
                    null,null,null);
            List<String> subTaskName=new ArrayList<>();
            while (cursor1.moveToNext())
            {
                subTaskName.add(cursor1.getString(cursor1.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL3)));
            }
            titles.add(title);
            tasks.add(taskName);
            scheduled.add(sched);
            descriptions.add(desc);
            subTasks.add(subTaskName);
        }
        cursor.close();*/
    }

    /**only call for TaskDetailActivity**/
    MyAdapter(FeedReaderContract.FeedReaderDbHelper dbHelper, Context context, int type, int id)
    {
        cont_text = context;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        activityType=type;
        typeNo=id;

        initDataSet(db);
        //select the subtasks from this task
        /*String selection= FeedReaderContract.SubTasks.COL1+" =?";
        String[] selectionArgs={((Integer) id).toString()};
        Cursor cursor=db.query(FeedReaderContract.SubTasks.TABLE_NAME,null,selection,
                selectionArgs,null,null,null);

        titles = new ArrayList<>();
        tasks= new ArrayList<>();
        scheduled = new ArrayList<>();
        descriptions=new ArrayList<>();
        subTasks=new ArrayList<>();
        while(cursor.moveToNext()) {
            String title = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL2));
            String taskName = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL3));
            String sched = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL5));
            String desc=cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL4));

            titles.add(title);
            tasks.add(taskName);
            scheduled.add(sched);
            descriptions.add(desc);
            subTasks.add(new ArrayList<String>());
        }
        cursor.close();*/
    }

    /**only call for DateView**/
    MyAdapter(FeedReaderContract.FeedReaderDbHelper dbHelper, Context context, int type, String date)
    {
        cont_text = context;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        activityType=type;
        typedate =date;

        initDataSet(db,date);
    }

    public void initDataSet(SQLiteDatabase db)
    {
        Log.i(TAG,"Initialising MyAdapter DataSet");
        if(activityType==0)
        {
            Cursor cursor=db.query(FeedReaderContract.Tasks.TABLE_NAME,null,null,null,null,null,null);
            titles = new ArrayList<>();
            tasks= new ArrayList<>();
            scheduled = new ArrayList<>();
            descriptions=new ArrayList<>();
            subTasks=new ArrayList<>();
            //Log.d(TAG," this is the date to be matched ");
            while(cursor.moveToNext()) {
                String title = cursor.getString(
                        cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL1));
                String taskName = cursor.getString(
                        cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL2));
                String sched = cursor.getString(
                        cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL4));
                String desc=cursor.getString(
                        cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL3));
                String[] selectionList={FeedReaderContract.SubTasks.COL3},
                        argList={title};
                String condn=FeedReaderContract.SubTasks.COL1+" =?";
                Cursor cursor1=db.query(
                        FeedReaderContract.SubTasks.TABLE_NAME,selectionList,condn,argList,
                        null,null,null);
                List<String> subTaskName=new ArrayList<>();
                while (cursor1.moveToNext())
                {
                    subTaskName.add(cursor1.getString(cursor1.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL3)));
                }
                Log.d(TAG,"Number of subtask for taskId: "+title+" is "+subTaskName.size());
                titles.add(title);
                tasks.add(taskName);
                scheduled.add(sched);
                descriptions.add(desc);
                subTasks.add(subTaskName);
            }
            cursor.close();
        }
        else if(activityType == 1)
        {
            String selection= FeedReaderContract.SubTasks.COL1+" =?";
            String[] selectionArgs={((Integer) typeNo).toString()};
            Cursor cursor=db.query(FeedReaderContract.SubTasks.TABLE_NAME,null,selection,
                    selectionArgs,null,null,null);

            titles = new ArrayList<>();
            tasks= new ArrayList<>();
            scheduled = new ArrayList<>();
            descriptions=new ArrayList<>();
            subTasks=new ArrayList<>();
            while(cursor.moveToNext()) {
                String title = cursor.getString(
                        cursor.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL2));
                String taskName = cursor.getString(
                        cursor.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL3));
                String sched = cursor.getString(
                        cursor.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL5));
                String desc=cursor.getString(
                        cursor.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL4));

                titles.add(title);
                tasks.add(taskName);
                scheduled.add(sched);
                descriptions.add(desc);
                subTasks.add(new ArrayList<String>());
            }
            cursor.close();
        }
    }

    /**only call for DateView**/
    public void initDataSet(SQLiteDatabase db,String date)
    {
        Log.d(TAG,"here1");
        //Cursor cursor = db.rawQuery("SELECT * FROM "+FeedReaderContract.Tasks.TABLE_NAME+" WHERE "+FeedReaderContract.Tasks.COL4+" = "+typedate,null);
        String[] selectionArgs={date};
        Cursor cursor=db.query(FeedReaderContract.Tasks.TABLE_NAME,null, FeedReaderContract.Tasks.COL4+" =?",selectionArgs,null,null,null);
        titles = new ArrayList<>();
        tasks= new ArrayList<>();
        scheduled = new ArrayList<>();
        descriptions=new ArrayList<>();
        subTasks=new ArrayList<>();
        extraVals=new ArrayList<>();
        typedate = date;
        Log.d(TAG," this is the date to be matched "+typedate);

        while(cursor.moveToNext()) {
            String title = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL1));
            Log.d(TAG,title+" here is the title");
            String taskName = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL2));
            String sched = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL4));
            String desc=cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.Tasks.COL3));
            List<String> path=new ArrayList<>();


            path.add("Heirarchy: "+FeedReaderContract.rootName+"/"+taskName);

            titles.add(title);
            tasks.add(taskName);
            scheduled.add(sched);
            descriptions.add(desc);
            subTasks.add(path);
            extraVals.add("0");
        }
        //cursor.close();
        //Log.d(TAG,"here2");
        String sqlQuery=" SELECT "+FeedReaderContract.SubTasks.COL2+","+
                "subName, subSched, subDesc, parName, taskId"+
                " FROM ( SELECT "+ FeedReaderContract.SubTasks.COL2+","+
                FeedReaderContract.SubTasks.TABLE_NAME+"."+FeedReaderContract.SubTasks.COL3+" AS subName,"+
                FeedReaderContract.SubTasks.TABLE_NAME+"."+FeedReaderContract.SubTasks.COL5+" AS subSched,"+
                FeedReaderContract.SubTasks.TABLE_NAME+"."+FeedReaderContract.SubTasks.COL4+" AS subDesc, "+
                FeedReaderContract.Tasks.TABLE_NAME+"."+FeedReaderContract.Tasks.COL4+" AS taskSched,"+
                FeedReaderContract.Tasks.TABLE_NAME+"."+ FeedReaderContract.Tasks.COL2+" AS parName, "+
                FeedReaderContract.Tasks.TABLE_NAME+"."+ FeedReaderContract.Tasks.COL1+" AS taskId"+
                " FROM "+FeedReaderContract.SubTasks.TABLE_NAME+" INNER JOIN "+ FeedReaderContract.Tasks.TABLE_NAME+
                " ON "+ FeedReaderContract.SubTasks.TABLE_NAME+"."+FeedReaderContract.SubTasks.COL1+"="+
                FeedReaderContract.Tasks.TABLE_NAME+"."+FeedReaderContract.Tasks.COL1+")"+
                " WHERE (taskSched=? AND subSched IS NULL) OR subSched =?;";
        String[] selecArgs={typedate,typedate};
        Log.d(TAG,"Query for subtasks: "+sqlQuery);
        cursor = db.rawQuery(sqlQuery,selecArgs);


        while(cursor.moveToNext()) {
            String title = cursor.getString(
                    cursor.getColumnIndexOrThrow(FeedReaderContract.SubTasks.COL2));
            Log.d(TAG,"Subtask id matched: "+title);
            String taskName = cursor.getString(
                    cursor.getColumnIndexOrThrow("subName"));
            String sched = cursor.getString(
                    cursor.getColumnIndexOrThrow("subSched"));
            String desc=cursor.getString(
                    cursor.getColumnIndexOrThrow("subDesc"));
            String parName=cursor.getString(
                    cursor.getColumnIndexOrThrow("parName"));
            String taskId=cursor.getString(
                    cursor.getColumnIndexOrThrow("taskId"));
            List<String> path=new ArrayList<>();



            path.add("Heirarchy: "+FeedReaderContract.rootName+"/"+parName+"/"+taskName);
            titles.add(title);
            tasks.add(taskName);
            scheduled.add(sched);
            descriptions.add(desc);
            subTasks.add(path);
            extraVals.add(taskId);
        }
        cursor.close();
    }
    /**1 based position index**/
    public void addNode(ContentValues values, int position)
    {
        Log.i(TAG,"Entered addNode method");
        if(activityType==0) {
            tasks.add((String) values.get(FeedReaderContract.Tasks.COL2));
            descriptions.add((String) values.get(FeedReaderContract.Tasks.COL3));
            scheduled.add((String) values.get(FeedReaderContract.Tasks.COL4));
            subTasks.add(new ArrayList<String>());
        }
        else
        {
            tasks.add((String) values.get(FeedReaderContract.SubTasks.COL3));
            descriptions.add((String) values.get(FeedReaderContract.SubTasks.COL4));
            scheduled.add((String) values.get(FeedReaderContract.SubTasks.COL5));
            subTasks.add(new ArrayList<String>());
        }
        this.notifyItemInserted(position);
        Log.i(TAG,"Item insertion notified at position "+position);
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public TextView name,date,desc,childNames;
        public Button edit;
        public MyViewHolder(CardView v) {
            super(v);
            name = (TextView) v.findViewById(R.id.mainTaskName);
            date=(TextView) v.findViewById(R.id.mainTaskDate);
            desc=v.findViewById(R.id.mainTaskDescription);
            childNames=v.findViewById(R.id.taskChildName);
            edit=v.findViewById(R.id.editButton);
        }

    }

    // Create new views (invoked by the layout manager)
    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // create a new view
        CardView v=(CardView) LayoutInflater.from(parent.getContext()).inflate(R.layout.my_card_view,parent,false);

        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        holder.name.setText(tasks.get(position));
        holder.date.setText(scheduled.get(position));
        holder.desc.setText(descriptions.get(position));
        List<String> nameList=subTasks.get(position);
        String listText="";
        for(String name:nameList)
            listText=listText+"\t- "+name+"\n";
        holder.childNames.setText(listText);
        final MyAdapter ref=this;
        holder.name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //implement onClick
                long pressTime = System.currentTimeMillis();
                if (pressTime - lastPressTime <= DOUBLE_PRESS_INTERVAL && activityType!=2) {
                    Intent intent;
                    if(activityType == 0) {
                        intent = new Intent(cont_text, TaskDetailActivity.class);
                        intent.putExtra("ID", Integer.toString(position));
                        intent.putExtra("Name", tasks.get(position));
                        intent.putExtra("Description",descriptions.get(position));
                        cont_text.startActivity(intent);
                    }
                    else if(activityType == 1){
                        intent = new Intent(cont_text, SubTaskDetailActivity.class);
                        intent.putExtra("subtaskId", Integer.toString(position));
                        intent.putExtra("taskId", Integer.toString(typeNo));
                        intent.putExtra("Name", tasks.get(position));
                        intent.putExtra("Description",descriptions.get(position));
                        cont_text.startActivity(intent);
                    }
                }
                else{
                    if (holder.desc.getVisibility() == View.GONE) {
                        holder.desc.setVisibility(View.VISIBLE);
                        holder.childNames.setVisibility(View.VISIBLE);
                        holder.edit.setVisibility(View.VISIBLE);
                        if(anotherOpen)
                        {
                            currentOpen.desc.setVisibility(View.GONE);
                            currentOpen.childNames.setVisibility(View.GONE);
                            currentOpen.edit.setVisibility(View.GONE);
                            currentOpen=holder;
                        }
                        else {
                            anotherOpen = true;
                            currentOpen=holder;
                        }
                    } else {
                        holder.desc.setVisibility(View.GONE);
                        holder.childNames.setVisibility(View.GONE);
                        holder.edit.setVisibility(View.GONE);
                        anotherOpen=false;
                    }
                }
                lastPressTime = pressTime;
            }
        });
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout layout = new LinearLayout(cont_text);
                layout.setOrientation(LinearLayout.VERTICAL);
                final EditText titlebox = new EditText(cont_text);
                final EditText descbox = new EditText(cont_text);
                final Button datebox = new Button(cont_text);
                titlebox.setHint(holder.name.getText());
                layout.addView(titlebox);
                descbox.setHint(holder.desc.getText());
                layout.addView(descbox);
                datebox.setHint("Date");
                layout.addView(datebox);
                if(activityType==0) {
                    AlertDialog dialog = new AlertDialog.Builder(cont_text)

                            .setTitle("Edit task")
                            .setMessage("What do you want to do next?")
                            .setView(layout)
                            .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //String task = String.valueOf(taskEditText.getText());
                                    //Log.d(TAG, "Task to add: " + task);
                                    String t1 = String.valueOf(titlebox.getText());
                                    String t2 = String.valueOf(descbox.getText());
                                    String t3 = String.valueOf(datebox.getText());

                                    ContentValues values = new ContentValues();
                                    if (t1.matches("")) {
                                        values.put(FeedReaderContract.Tasks.COL2, tasks.get(position));
                                    } else {
                                        values.put(FeedReaderContract.Tasks.COL2, t1);
                                    }
                                    if (t2.matches("")) {
                                        values.put(FeedReaderContract.Tasks.COL3, descriptions.get(position));
                                    } else {
                                        values.put(FeedReaderContract.Tasks.COL3, t2);
                                    }
                                    if (t3.matches("")) {
                                        values.put(FeedReaderContract.Tasks.COL4, scheduled.get(position));
                                    } else {
                                        values.put(FeedReaderContract.Tasks.COL4, t3);
                                    }

                                    FeedReaderContract.FeedReaderDbHelper dbHelper = new FeedReaderContract.FeedReaderDbHelper(cont_text);
                                    FeedReaderContract.updateTask(dbHelper, values, position, ref);
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .create();
                    int mYear, mMonth, mDay, mHour, mMinute;
                    final Calendar c = Calendar.getInstance();
                    mYear = c.get(Calendar.YEAR);
                    mMonth = c.get(Calendar.MONTH);
                    mDay = c.get(Calendar.DAY_OF_MONTH);
                    final DatePickerDialog datedialog = new DatePickerDialog(cont_text,
                            new DatePickerDialog.OnDateSetListener() {

                                @Override
                                public void onDateSet(DatePicker view, int year,
                                                      int monthOfYear, int dayOfMonth) {
                                    datebox.setText(year+"-" + (monthOfYear + 1) +"-"+dayOfMonth);
                                }
                            },mYear,mMonth,mDay);

                    datebox.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            datedialog.show();
                        }});



                    dialog.show();
                }
                else if(activityType==1)
                {
                    AlertDialog dialog = new AlertDialog.Builder(cont_text)

                            .setTitle("Edit sub-task")
                            .setMessage("What do you want to do next?")
                            .setView(layout)
                            .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //String task = String.valueOf(taskEditText.getText());
                                    //Log.d(TAG, "Task to add: " + task);
                                    String t1 = String.valueOf(titlebox.getText());
                                    String t2 = String.valueOf(descbox.getText());
                                    String t3 = String.valueOf(datebox.getText());

                                    ContentValues values = new ContentValues();
                                    if (t1.matches("")) {
                                        values.put(FeedReaderContract.SubTasks.COL3, tasks.get(position));
                                    } else {
                                        values.put(FeedReaderContract.SubTasks.COL3, t1);
                                    }
                                    if (t2.matches("")) {
                                        values.put(FeedReaderContract.SubTasks.COL4, descriptions.get(position));
                                    } else {
                                        values.put(FeedReaderContract.SubTasks.COL4, t2);
                                    }
                                    if (t3.matches("")) {
                                        values.put(FeedReaderContract.SubTasks.COL5, scheduled.get(position));
                                    } else {
                                        values.put(FeedReaderContract.SubTasks.COL5, t3);
                                    }

                                    FeedReaderContract.FeedReaderDbHelper dbHelper = new FeedReaderContract.FeedReaderDbHelper(cont_text);
                                    FeedReaderContract.updateSubTask(dbHelper, values, position, typeNo, ref);
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .create();
                    int mYear, mMonth, mDay, mHour, mMinute;
                    final Calendar c = Calendar.getInstance();
                    mYear = c.get(Calendar.YEAR);
                    mMonth = c.get(Calendar.MONTH);
                    mDay = c.get(Calendar.DAY_OF_MONTH);
                    final DatePickerDialog datedialog = new DatePickerDialog(cont_text,
                            new DatePickerDialog.OnDateSetListener() {

                                @Override
                                public void onDateSet(DatePicker view, int year,
                                                      int monthOfYear, int dayOfMonth) {
                                    datebox.setText(year+"-" + (monthOfYear + 1) +"-"+dayOfMonth);
                                }
                            },mYear,mMonth,mDay);

                    datebox.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            datedialog.show();
                        }});

                    dialog.show();
                }
                else
                {//determine if the holder is of a task or a sub task
                    if(subTasks.get(position).size()==2)
                    {//task node
                        AlertDialog dialog = new AlertDialog.Builder(cont_text)

                                .setTitle("Edit task")
                                .setMessage("What do you want to do next?")
                                .setView(layout)
                                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //String task = String.valueOf(taskEditText.getText());
                                        //Log.d(TAG, "Task to add: " + task);
                                        String t1 = String.valueOf(titlebox.getText());
                                        String t2 = String.valueOf(descbox.getText());
                                        String t3 = String.valueOf(datebox.getText());

                                        ContentValues values = new ContentValues();
                                        if (t1.matches("")) {
                                            values.put(FeedReaderContract.Tasks.COL2, tasks.get(position));
                                        } else {
                                            values.put(FeedReaderContract.Tasks.COL2, t1);
                                        }
                                        if (t2.matches("")) {
                                            values.put(FeedReaderContract.Tasks.COL3, descriptions.get(position));
                                        } else {
                                            values.put(FeedReaderContract.Tasks.COL3, t2);
                                        }
                                        if (t3.matches("")) {
                                            values.put(FeedReaderContract.Tasks.COL4, scheduled.get(position));
                                        } else {
                                            values.put(FeedReaderContract.Tasks.COL4, t3);
                                        }

                                        values.put("Date",typedate);
                                        FeedReaderContract.FeedReaderDbHelper dbHelper = new FeedReaderContract.FeedReaderDbHelper(cont_text);
                                        FeedReaderContract.updateTask(dbHelper, values, Integer.parseInt(titles.get(position)), ref);
                                        ref.notifyItemChanged(position);//the one in FeedReaderContract is notifying for incorrect item
                                        Log.d(TAG,"Item change notified at position: "+position);
                                    }
                                })
                                .setNegativeButton("Cancel", null)
                                .create();
                        int mYear, mMonth, mDay, mHour, mMinute;
                        final Calendar c = Calendar.getInstance();
                        mYear = c.get(Calendar.YEAR);
                        mMonth = c.get(Calendar.MONTH);
                        mDay = c.get(Calendar.DAY_OF_MONTH);
                        final DatePickerDialog datedialog = new DatePickerDialog(cont_text,
                                new DatePickerDialog.OnDateSetListener() {

                                    @Override
                                    public void onDateSet(DatePicker view, int year,
                                                          int monthOfYear, int dayOfMonth) {
                                        datebox.setText(year+"-" + (monthOfYear + 1) +"-"+dayOfMonth);
                                    }
                                },mYear,mMonth,mDay);

                        datebox.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                datedialog.show();
                            }});



                        dialog.show();
                    }
                    else
                    {//subtask node
                        AlertDialog dialog = new AlertDialog.Builder(cont_text)

                                .setTitle("Edit sub-task")
                                .setMessage("What do you want to do next?")
                                .setView(layout)
                                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //String task = String.valueOf(taskEditText.getText());
                                        //Log.d(TAG, "Task to add: " + task);
                                        String t1 = String.valueOf(titlebox.getText());
                                        String t2 = String.valueOf(descbox.getText());
                                        String t3 = String.valueOf(datebox.getText());

                                        ContentValues values = new ContentValues();
                                        if (t1.matches("")) {
                                            values.put(FeedReaderContract.SubTasks.COL3, tasks.get(position));
                                        } else {
                                            values.put(FeedReaderContract.SubTasks.COL3, t1);
                                        }
                                        if (t2.matches("")) {
                                            values.put(FeedReaderContract.SubTasks.COL4, descriptions.get(position));
                                        } else {
                                            values.put(FeedReaderContract.SubTasks.COL4, t2);
                                        }
                                        if (t3.matches("")) {
                                            values.put(FeedReaderContract.SubTasks.COL5, scheduled.get(position));
                                        } else {
                                            values.put(FeedReaderContract.SubTasks.COL5, t3);
                                        }

                                        values.put("Date",typedate);
                                        FeedReaderContract.FeedReaderDbHelper dbHelper = new FeedReaderContract.FeedReaderDbHelper(cont_text);
                                        FeedReaderContract.updateSubTask(dbHelper, values, Integer.parseInt(titles.get(position)), Integer.parseInt(extraVals.get(position)), ref);
                                        ref.notifyItemChanged(position);//the one in FeedReaderContract is notifying for incorrect item
                                        Log.d(TAG,"Item change notified at position: "+position);
                                    }
                                })
                                .setNegativeButton("Cancel", null)
                                .create();
                        int mYear, mMonth, mDay, mHour, mMinute;
                        final Calendar c = Calendar.getInstance();
                        mYear = c.get(Calendar.YEAR);
                        mMonth = c.get(Calendar.MONTH);
                        mDay = c.get(Calendar.DAY_OF_MONTH);
                        final DatePickerDialog datedialog = new DatePickerDialog(cont_text,
                                new DatePickerDialog.OnDateSetListener() {

                                    @Override
                                    public void onDateSet(DatePicker view, int year,
                                                          int monthOfYear, int dayOfMonth) {
                                        datebox.setText(year+"-" + (monthOfYear + 1) +"-"+dayOfMonth);
                                    }
                                },mYear,mMonth,mDay);

                        datebox.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                datedialog.show();
                            }});

                        dialog.show();
                    }
                }

            }
        });

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return tasks.size();
    }
    //use the notifyItemChanged() method when adding functionality for editing tasks
}
